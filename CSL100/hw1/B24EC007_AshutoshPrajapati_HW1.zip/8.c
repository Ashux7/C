#include<stdio.h>
int main(){
    int count=0,n;
    printf("Enter n:");
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=0;j<n;j++){
            for(int k=j;k<n;k++){
                int a= (j*j)+(k*k);
                if(a==i){
                    count++;
                }
            }
        }
    }
    printf("%d",count);
    return 0;
}